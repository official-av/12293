export const environment = {
  production: true,
  api_url: 'http://portal-web-api.us-east-1.elasticbeanstalk.com/api/v1/'
};

import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AboutComponent} from './shared/static/about/about.component';
import {HelpComponent} from './shared/static/help/help.component';
import {ContactComponent} from './shared/static/contact/contact.component';
import {SignupComponent} from './auth/signup/signup.component';
import {ProfileviewComponent} from './profile/profileview/profileview.component';
import {DashboardComponent} from './core/dashboard/dashboard.component';
import {StudentDataComponent} from './core/student-data/student-data.component';
import {StudentListComponent} from './core/student-data/student-list/student-list.component';
import {ComparisonComponent} from './core/comparison/comparison.component';
import {SelectionComponent} from './core/selection/selection.component';
import {WelcomeComponent} from './shared/welcome/welcome.component';

const routes: Routes = [
  {
    path: 'contact',
    component: ContactComponent
  },
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: 'help',
    component: HelpComponent
  },
  {
    path: 'register',
    component: SignupComponent
  },
  {
    path: 'profile',
    component: ProfileviewComponent
  },
  {
    path: 'home',
    component: DashboardComponent
  },
  {
    path: 'uploadData',
    component: StudentDataComponent
  },
  {
    path: 'studentsAdded',
    component: StudentListComponent
  },
  {
    path: 'comparison',
    component: ComparisonComponent
  },
  {
    path: 'eduDashboard',
    component: SelectionComponent
  },
  {
    path: '',
    component: WelcomeComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

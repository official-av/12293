export interface RegisterUser {
  username: string;
  password: string;
  confirm_password: string;
  schoolcode: string;
  email: string;
  contact: number;
  location: string;
}

import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {AuthService} from '../auth.service';
import {RegisterUser} from '../registerUser.interface';
import {ModalsService} from '../../modals.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  firstFormGroup: FormGroup;
  // contains school,email and contact
  secondFormGroup: FormGroup;
  // contains username,pwd + cnf_pwd
  schools = ['NIET_8', 'JSS_07', 'IMS_05', 'AKG_12'];
  filteredSchools: Observable<any[]>;
  // TODO: Add methods for backend
  // TODO: Make UI responsive for mobile
  constructor(private authService: AuthService, private modalsService: ModalsService) {
  }

  ngOnInit() {
    this.firstFormGroup = new FormGroup({
      'school': new FormControl(null, Validators.required),
      'location': new FormControl(null, Validators.required),
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'contact': new FormControl(null, [Validators.required, Validators.pattern('[0-9]{10}')])
    });
    this.secondFormGroup = new FormGroup({
      'username': new FormControl(null, [Validators.required, Validators.pattern('[a-zA-Z0-9]+'), Validators.minLength(8)]),
      'password': new FormControl(null, [Validators.required, Validators.minLength(8)
        /*, this.confirmPasswordValidator2.bind(this)*/]),
      'cnf_password': new FormControl(null, [Validators.required, Validators.minLength(8), this.confirmPasswordValidator.bind(this)]),
    });
    /*this.filteredSchools = this.secondFormGroup.controls['school'].valueChanges
      .pipe(startWith(''), map(val => this.filter(val)));*/
  }

  /*filter(val: string): string[] {
    return this.filteredSchools.filter(school => school.indexOf(val) === 0);
  }*/

  confirmPasswordValidator(control: FormControl): { [s: string]: boolean } {
    if (this.secondFormGroup && control.value !== this.secondFormGroup.get('password').value) {
      return {'differentPasswords': true};
    } else {
      return null;
    }
  }

  /*confirmPasswordValidator2(control: FormControl): { [s: string]: boolean } {
    if (this.secondFormGroup
      && (control.value !== this.secondFormGroup.get('cnf_password').value
        && this.secondFormGroup.get('cnf_password').value)) {
      return {'differentPasswords': true};
    } else {
      return null;
    }
  }
*/
  onSubmit() {
    console.log(this.firstFormGroup.value);
    console.log(this.secondFormGroup.value);
    const user: RegisterUser = {
        username: this.secondFormGroup.get('username').value,
        password: this.secondFormGroup.get('password').value,
        confirm_password: this.secondFormGroup.get('cnf_password').value,
        schoolcode: this.firstFormGroup.get('school').value,
        email: this.firstFormGroup.get('email').value,
        contact: this.firstFormGroup.get('contact').value,
        location: this.firstFormGroup.get('location').value
      }
    ;
    this.authService.register(user)
      .then(result => {
        this.modalsService.openLoginModal();
        console.log(result);
      })
      .catch(error => console.log(error));
  }

}

export class ExtraCurricular {
  activity_name: string;
  inter_played: number;
  inter_won: number;
  intra_played: number;
  intra_won: number;
}

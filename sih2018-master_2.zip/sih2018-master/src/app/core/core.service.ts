import {Student} from './student.model';
import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class CoreService {
  addedStudents: Student[] = [];
  data = new Subject<Student[]>();

  constructor(private router: Router, private http: HttpClient) {
  }

  addStudentsData(data: Student) {
    this.addedStudents.push(data);
    this.router.navigate(['studentsAdded']);
  }

  getStudentsData() {
    return this.addedStudents.slice();
  }

  redirectToAdd() {
    this.router.navigate(['uploadData']);
  }

  pushStudents(data: Student) {
    const temp = {
      'sports_score': 8,
      'academics':
        {
          'eng': 54,
          'maths': 88,
          'science': 34,
          'evs': 40,
          'sst': 50
        },
      'grade': '2',
      'teacher_remark': 'random',
      'acad_year': '2017-2018',
      'preferred': 'sports',
      'extra_curricular': [
        {
          'activity_name': 'singing',
          'inter_played': 20,
          'inter_won': 12,
          'intra_played': 13,
          'intra_won': 10
        }],
      'sports': [
        {
          'sport_name': 'archery',
          'semi': 12,
          'matches': 20,
          'final': 13,
          'won': 10
        }],
      'dob': '1999-11-03',
      'school': '1',
      'rollno': '34',
      'gender': 'male',
      'student_name': 'raju',
      'acad_score': 9,
      'extra_score': 8
    };
    return new Promise((resolve, reject) => {
      this.http.post(environment.api_url + 'auth/studentportal/', data)
        .subscribe(result => resolve('success'),
          error => reject(error));
    });
  }
}

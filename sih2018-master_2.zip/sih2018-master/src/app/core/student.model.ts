import {Academics} from './academics.model';
import {Sports} from './sports.model';
import {ExtraCurricular} from './extra_curricular.model';

export class Student {
  student_name: string;
  rollno: string;
  school: string;
  grade: string;
  acad_year: string;
  gender: 'male' | 'female' | 'other';
  dob: string;
  academics: Academics;
  sports: Sports[];
  extra_curricular: ExtraCurricular[];
  teacher_remark: string;
  preferred: 'academics' | 'sports' | 'extra_curricular' | 'all';
  sports_score?: number;
  acad_score?: number;
  extra_score?: number;

  constructor() {
    this.acad_score = 9;
    this.extra_score = 8;
    this.sports_score = 7;
  }
}

export class Academics {
  eng: number;
  maths: number;
  science: number;
  evs: number;
  sst: number;
}

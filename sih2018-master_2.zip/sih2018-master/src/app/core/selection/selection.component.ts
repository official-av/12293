import {Component, OnInit} from '@angular/core';
import {Student} from '../student.model';
import {MatTableDataSource} from '@angular/material';
import {ModalsService} from '../../modals.service';
import {CoreService} from '../core.service';

@Component({
  selector: 'app-selection',
  templateUrl: './selection.component.html',
  styleUrls: ['./selection.component.scss']
})
export class SelectionComponent implements OnInit {
  sportsDisplayedColumns = ['Student_Name', 'Sports', 'Score', 'Details'];
  academicsDisplayedColumns = ['Student_Name', 'english', 'maths', 'science', 'social_science', 'env', 'score', 'Details'];
  extraDisplayedColumns = ['Student_Name', 'Activities', 'Score', 'Details'];
  dataSource = new MatTableDataSource<Student>();
  temp: Student = {
    'sports_score': 8,
    'academics':
      {
        'eng': 54,
        'maths': 88,
        'science': 34,
        'evs': 40,
        'sst': 50
      },
    grade: '2',
    'teacher_remark': 'random',
    'acad_year': '2017-2018',
    'preferred': 'sports',
    'extra_curricular': [
      {
        'activity_name': 'singing',
        'inter_played': 20,
        'inter_won': 12,
        'intra_played': 13,
        'intra_won': 10
      }],
    'sports': [
      {
        'sport_name': 'archery',
        'semi': 12,
        'matches': 20,
        'final': 13,
        'won': 10
      }],
    'dob': '1999-12-08',
    'school': '1',
    'rollno': '34',
    'gender': 'male',
    'student_name': 'raju',
    'acad_score': 9,
    'extra_score': 8
  };

  constructor(private modalsService: ModalsService, private coreService: CoreService) {
    this.dataSource.data = this.coreService.getStudentsData();
  }

  ngOnInit() {

  }

  checkDetails(data: Student) {
    console.log(data);
    this.modalsService.openStudentDetailsModal(data);
  }

}

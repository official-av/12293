export class Sports {
  sport_name: string;
  matches: number;
  semi: number;
  final: number;
  won: number;
}

import {NgModule} from '@angular/core';
import {DashboardComponent} from './dashboard/dashboard.component';
import {CommonModule} from '@angular/common';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MaterialModule} from '../material.module';
import {StudentDataComponent} from './student-data/student-data.component';
import {ReactiveFormsModule} from '@angular/forms';
import {StudentListComponent} from './student-data/student-list/student-list.component';
import {SportsDataComponent} from './student-data/sports-data/sports-data.component';
import {ExtraCurricularDataComponent} from './student-data/extra-curricular-data/extra-curricular-data.component';
import {SportListComponent} from './student-data/sport-list/sport-list.component';
import {ExtraCurricularListComponent} from './student-data/extra-curricular-list/extra-curricular-list.component';
import {SportDetailComponent} from './student-data/sport-list/sport-detail/sport-detail.component';
import {ExtraDetailComponent} from './student-data/extra-curricular-list/extra-detail/extra-detail.component';
import {CoreService} from './core.service';
import {StudentDetailComponent} from './student-data/student-list/student-detail/student-detail.component';
import {ComparisonComponent} from './comparison/comparison.component';
import {SelectionComponent} from './selection/selection.component';
import {CheckDetailComponent} from './student-data/check-detail/check-detail.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MaterialModule,
    ReactiveFormsModule
  ],
  exports: [],
  declarations: [DashboardComponent, StudentDataComponent, StudentListComponent, SportsDataComponent, ExtraCurricularDataComponent, SportListComponent, ExtraCurricularListComponent, SportDetailComponent, ExtraDetailComponent, StudentDetailComponent, ComparisonComponent, SelectionComponent, CheckDetailComponent],
  providers: [CoreService]
})
export class CoreModule {

}

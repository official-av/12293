import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {AuthService} from '../../auth/auth.service';
import {User} from '../../profile/user.model';
import {Sports} from '../sports.model';
import {ExtraCurricular} from '../extra_curricular.model';
import {Student} from '../student.model';
import {CoreService} from '../core.service';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-student-data',
  templateUrl: './student-data.component.html',
  styleUrls: ['./student-data.component.scss']
})
export class StudentDataComponent implements OnInit {
  maxDate: Date;
  studentData: FormGroup;
  sports: Sports[] = [];
  extraCurricular: ExtraCurricular[] = [];
  academicsData: FormGroup;
  otherData: FormGroup;
  schoolCode: string;
  acad_year: string;
  domains = ['academics', 'sports', 'extra_curricular', 'all'];
  classes = [1, 2, 3, 4, 5, 6, 7, 8];
  genders = ['Male', 'Female', 'Other'];

  constructor(private authService: AuthService, private coreService: CoreService, private datePipe: DatePipe) {
    this.schoolCode = (<User>this.authService.getUserDetails()).schoolcode;
    this.acad_year = this.getAcadYear();
  }

  ngOnInit() {
    this.maxDate = new Date();
    this.maxDate.setFullYear(this.maxDate.getFullYear() - 6);

    this.studentData = new FormGroup({
      student_name: new FormControl(null, [Validators.required, Validators.pattern('[a-zA-Z ]*')]),
      rollno: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      dob: new FormControl(null, Validators.required),
      grade: new FormControl(null, Validators.required),
      gender: new FormControl(null, Validators.required),
    });

    this.academicsData = new FormGroup({
      eng: new FormControl(null, [Validators.required/*, Validators.pattern('[0-9]{1-3}')*/]),
      maths: new FormControl(null, [Validators.required]),
      science: new FormControl(null, [Validators.required]),
      evs: new FormControl(null, [Validators.required]),
      sst: new FormControl(null, [Validators.required])
    });

    this.otherData = new FormGroup({
      teacher_remark: new FormControl(null),
      preferred: new FormControl('all', Validators.required)
    });
  }

  getDate() {
    return this.studentData.get('dob').value;
  }

  getAcadYear() {
    const curr_year = new Date().getFullYear();
    const curr_month = new Date().getMonth();
    let other_year;
    if (curr_month > 3) {
      other_year = curr_year + 1;
      return curr_year.toString() + '-' + other_year.toString();
    } else {
      other_year = curr_year - 1;
      return other_year.toString() + '-' + curr_year.toString();
    }
  }

  addSport(sport: Sports) {
    this.sports.push(sport);
  }

  addActivity(activity: ExtraCurricular) {
    this.extraCurricular.push(activity);
  }

  onSubmit() {
    const date = this.getDate();
    const studentData: Student = {
      student_name: this.studentData.get('student_name').value,
      rollno: this.studentData.get('rollno').value,
      school: this.schoolCode,
      grade: this.studentData.get('grade').value,
      acad_year: this.acad_year,
      gender: this.studentData.get('gender').value,
      dob: this.datePipe.transform(date, 'yyyy-MM-dd'),
      academics: {
        eng: this.academicsData.get('eng').value,
        maths: this.academicsData.get('maths').value,
        science: this.academicsData.get('science').value,
        sst: this.academicsData.get('sst').value,
        evs: this.academicsData.get('evs').value,
      },
      sports: this.sports,
      extra_curricular: this.extraCurricular,
      preferred: this.otherData.get('preferred').value,
      teacher_remark: this.otherData.get('teacher_remark').value
    };
    console.log(studentData);
    this.coreService.addStudentsData({...studentData, acad_score: 7, sports_score: 8, extra_score: 9});

  }

}

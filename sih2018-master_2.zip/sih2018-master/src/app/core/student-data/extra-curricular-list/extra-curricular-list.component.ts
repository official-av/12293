import {Component, Input, OnInit} from '@angular/core';
import {ExtraCurricular} from '../../extra_curricular.model';

@Component({
  selector: 'app-extra-curricular-list',
  templateUrl: './extra-curricular-list.component.html',
  styleUrls: ['./extra-curricular-list.component.scss']
})
export class ExtraCurricularListComponent implements OnInit {
  @Input() academics: ExtraCurricular[];

  constructor() {
  }

  ngOnInit() {
  }

}

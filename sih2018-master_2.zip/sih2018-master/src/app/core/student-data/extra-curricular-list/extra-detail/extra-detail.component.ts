import {Component, Input, OnInit} from '@angular/core';
import {ExtraCurricular} from '../../../extra_curricular.model';

@Component({
  selector: 'app-extra-detail',
  templateUrl: './extra-detail.component.html',
  styleUrls: ['./extra-detail.component.scss']
})
export class ExtraDetailComponent implements OnInit {
  @Input() activity: ExtraCurricular;

  constructor() {
  }

  ngOnInit() {
  }

}

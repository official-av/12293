import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtraCurricularDataComponent } from './extra-curricular-data.component';

describe('ExtraCurricularDataComponent', () => {
  let component: ExtraCurricularDataComponent;
  let fixture: ComponentFixture<ExtraCurricularDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExtraCurricularDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtraCurricularDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

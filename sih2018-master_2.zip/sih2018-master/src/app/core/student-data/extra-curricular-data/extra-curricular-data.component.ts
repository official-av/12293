import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ExtraCurricular} from '../../extra_curricular.model';

@Component({
  selector: 'app-extra-curricular-data',
  templateUrl: './extra-curricular-data.component.html',
  styleUrls: ['./extra-curricular-data.component.scss']
})
export class ExtraCurricularDataComponent implements OnInit {

  extraCurrData: FormGroup;
  activites = ['Music', 'Dance', 'Arts'];
  @Output() activity = new EventEmitter<ExtraCurricular>();

  constructor() {
  }

  ngOnInit() {
    this.extraCurrData = new FormGroup({
      activity_name: new FormControl(null, Validators.required),
      inter_played: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      inter_won: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      intra_played: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      intra_won: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
    });
  }

  addActivity() {
    this.activity.emit({
        activity_name: this.extraCurrData.get('activity_name').value,
        inter_played: this.extraCurrData.get('inter_played').value,
        inter_won: this.extraCurrData.get('inter_won').value,
        intra_played: this.extraCurrData.get('intra_played').value,
        intra_won: this.extraCurrData.get('intra_won').value
      }
    );
  }

}

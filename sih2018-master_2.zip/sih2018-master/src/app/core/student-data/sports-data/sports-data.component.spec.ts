import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SportsDataComponent } from './sports-data.component';

describe('SportsDataComponent', () => {
  let component: SportsDataComponent;
  let fixture: ComponentFixture<SportsDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SportsDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SportsDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Sports} from '../../sports.model';

@Component({
  selector: 'app-sports-data',
  templateUrl: './sports-data.component.html',
  styleUrls: ['./sports-data.component.scss']
})
export class SportsDataComponent implements OnInit {
  sportsData: FormGroup;
  sportDetails = ['Archery', 'Basketball', 'Badminton'];
  @Output() sport = new EventEmitter<Sports>();

  constructor() {
  }

  ngOnInit() {
    this.sportsData = new FormGroup({
      sport_name: new FormControl(null, Validators.required),
      matches: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      semi: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      final: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
      won: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+')]),
    });
  }

  addSport() {
    this.sport.emit({
      sport_name: this.sportsData.get('sport_name').value,
      matches: this.sportsData.get('matches').value,
      semi: this.sportsData.get('semi').value,
      final: this.sportsData.get('final').value,
      won: this.sportsData.get('won').value
    });
  }
}

import {Component, Input, OnInit} from '@angular/core';
import {Sports} from '../../../sports.model';

@Component({
  selector: 'app-sport-detail',
  templateUrl: './sport-detail.component.html',
  styleUrls: ['./sport-detail.component.scss']
})
export class SportDetailComponent implements OnInit {
  @Input() sport: Sports;

  constructor() {
  }

  ngOnInit() {
  }

}

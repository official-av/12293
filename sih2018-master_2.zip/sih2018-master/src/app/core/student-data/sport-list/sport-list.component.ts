import {Component, Input, OnInit} from '@angular/core';
import {Sports} from '../../sports.model';

@Component({
  selector: 'app-sport-list',
  templateUrl: './sport-list.component.html',
  styleUrls: ['./sport-list.component.scss']
})
export class SportListComponent implements OnInit {
  @Input() sportsArray: Sports[];

  constructor() {
  }

  ngOnInit() {
  }

}

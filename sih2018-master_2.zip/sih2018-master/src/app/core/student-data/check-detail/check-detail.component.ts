import {Component, Inject, OnInit} from '@angular/core';
import {Student} from '../../student.model';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';

@Component({
  selector: 'app-check-detail',
  templateUrl: './check-detail.component.html',
  styleUrls: ['./check-detail.component.scss']
})
export class CheckDetailComponent implements OnInit {
  studentData: Student;

  constructor(public dialogRef: MatDialogRef<CheckDetailComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.studentData = this.data.student;
  }

}

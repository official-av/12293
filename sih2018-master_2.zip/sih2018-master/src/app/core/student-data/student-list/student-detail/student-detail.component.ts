import {Component, Input, OnInit} from '@angular/core';
import {Student} from '../../../student.model';


@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.scss']
})
export class StudentDetailComponent implements OnInit {
  @Input() studentDetail: Student;

  constructor() {
  }

  ngOnInit() {
  }

}

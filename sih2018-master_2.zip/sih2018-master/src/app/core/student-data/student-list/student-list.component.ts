import {Component, OnInit} from '@angular/core';
import {CoreService} from '../../core.service';
import {Student} from '../../student.model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.scss']
})

export class StudentListComponent implements OnInit {
  studentData: Student[] = [];

  constructor(private coreService: CoreService, private router: Router) {
  }

  ngOnInit() {
    this.studentData = this.coreService.getStudentsData();
  }

  submit() {
    this.coreService.pushStudents(this.studentData[0]).then(res => console.log(res)).catch(error => console.log(error));
    this.router.navigate(['eduDashboard']);
  }

}

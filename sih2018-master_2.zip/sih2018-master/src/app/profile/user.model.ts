export class User {
  username: string;
  schoolcode: string;
  email: string;
  contact: number;
  location: string;
}
